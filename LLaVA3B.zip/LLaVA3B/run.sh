#!/bin/bash

docker run -it --rm --runtime=nvidia --network=host \
	-e UVLOOP_NO_EXTENSIONS=1 \
	-p 9000:9000 \
	-e DOCKER_PULL=always --pull always \
	-e HF_HUB_CACHE=/root/.cache/huggingface \
	-v /mnt/nvme/cache:/root/.cache \
	dustynv/vllm:0.6.6.post1-r36.4.0 \
	vllm serve llava-hf/llava-1.5-7b-hf \
      --host=0.0.0.0 \
      --port=9000 \
      --dtype=auto \
      --max-num-seqs=1 \
      --max-model-len=1024 \
      --chat-template-content-format=openai \
      --trust-remote-code \
      --gpu-memory-utilization=0.75 \
      --uvicorn-log-level=debug \
      --quantization=bitsandbytes \
      --load-format=bitsandbytes
